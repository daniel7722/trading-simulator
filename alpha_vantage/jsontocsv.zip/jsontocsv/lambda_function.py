
import io
import requests
import csv
import json
import boto3

def convert_raw_to_rfnd(json_content):
    csvio = io.StringIO()
    writer = csv.DictWriter(csvio, fieldnames=["timestamp", "open", "high", "low", "close", "volume"])
    writer.writeheader()
    time_series = json_content.get("Time Series (5min)", {})
    for timestamp, data in time_series.items():
        row = {
            "timestamp": timestamp,
            "open": data.get("1. open", ""),
            "high": data.get("2. high", ""),
            "low": data.get("3. low", ""),
            "close": data.get("4. close", ""),
            "volume": data.get("5. volume", "")
        }
        writer.writerow(row)
    csv_data = csvio.getvalue()
    csvio.close()
    return csv_data

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket_name = "dhstockdata"
    raw_data_filepath = "now_data.json"
    output_filename = "now_data.csv"

    response = s3.get_object(Bucket=bucket_name, Key=raw_data_filepath)
    json_content = json.loads(response['Body'].read().decode('utf-8'))
    csv_data = convert_raw_to_rfnd(json_content)

    s3.put_object(Bucket=bucket_name, Key=output_filename, Body=csv_data)

    return {
        'statusCode': 200,
        'body': json.dumps('Successfully converted to csv and stored in rfnd folder!')
    }